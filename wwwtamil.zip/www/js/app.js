var app = angular.module('slidebox', ['ionic', 'tabSlideBox'])
		.run(['$q', '$http', '$rootScope', '$location', '$window', '$timeout', 
					function($q, $http, $rootScope, $location, $window, $timeout){
	    
	        $rootScope.$on("$locationChangeStart", function(event, next, current){
	            $rootScope.error = null;
	            console.log("Route change!!!", $location.path());
	            var path = $location.path();
	            
	            
	            console.log("App Loaded!!!");
	        });
	    }
	    ]);
		
		app.config(function($stateProvider, $urlRouterProvider) {
			$stateProvider.state('index', {
				url : '/',
				templateUrl : 'index.html',
				controller : 'IndexCtrl'
			});
		
			$urlRouterProvider.otherwise("/");
		});
		
        app.controller("IndexCtrl", ['$rootScope', "$scope", "$stateParams", "$q", "$location", "$window", '$timeout', 
			function($rootScope, $scope, $stateParams, $q, $location, $window, $timeout){
			$scope.onSlideMove = function(data){
				//alert("You have selected " + data.index + " tab");
			};	
        }
        ])

        var app = angular.module('slidebox', ['ionic', 'tabSlideBox'])
		.run(['$q', '$http', '$rootScope', '$location', '$window', '$timeout', 
					function($q, $http, $rootScope, $location, $window, $timeout){
	    
	        $rootScope.$on("$locationChangeStart", function(event, next, current){
	            $rootScope.error = null;
	            console.log("Route change!!!", $location.path());
	            var path = $location.path();
	            
	            
	            console.log("App Loaded!!!");
	        });
	    }
	    ]);
		
		app.config(function($stateProvider, $urlRouterProvider) {
			$stateProvider.state('index', {
				url : '/',
				templateUrl : 'index.html',
				controller : 'IndexCtrl'
			});
		
			$urlRouterProvider.otherwise("/");
		});
		
        app.controller("IndexCtrl", ['$rootScope', "$scope", "$stateParams", "$q", "$location", "$window", '$timeout', 
			function($rootScope, $scope, $stateParams, $q, $location, $window, $timeout){
			$scope.onSlideMove = function(data){
				//alert("You have selected " + data.index + " tab");
			};	
        }
        ])

app.controller("FeedController", function($http, $scope) {
 
/*

$http({
  method: 'GET',
  url: 'https://api.backand.com:443/1/objects/meme?pageSize=20&pageNumber=1'
}).then(function successCallback(response) {
  alert("Success"+JSON.stringify(response));
    // this callback will be called asynchronously
    // when the response is available
  }, function errorCallback(response) {
    alert("Error"+JSON.stringify(response));
    // called asynchronously if an error occurs
    // or server returns response with an error status.
  });
 */
    $scope.init = function() {
        //$http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://feeds.feedburner.com/dinamalar/Front_page_news" } })
           
$http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://rss.cnn.com/rss/edition.rss" } })
            .success(function(data) {
                $scope.con=data.responseData.feed.entries;
            
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });

        $http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://rss.dinamalar.com/?cat=pot1" } })
            .success(function(data) {
                $scope.con1=data.responseData.feed.entries;
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });



        $http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://rss.dinamalar.com/?cat=INL1" } })
            .success(function(data) {
                $scope.world=data.responseData.feed.entries;
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });



        $http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://cinema.dinamalar.com/rss.php" } })
            .success(function(data) {
                $scope.cinema=data.responseData.feed.entries;
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });





        $http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://sports.dinamalar.com/rss/Cricket" } })
            .success(function(data) {
                $scope.cricket=data.responseData.feed.entries;
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });


        $http.get("http://ajax.googleapis.com/ajax/services/feed/load", { params: { "v": "1.0","num":"40", "q": "http://sports.dinamalar.com/rss/Football" } })
            .success(function(data) {
                $scope.football=data.responseData.feed.entries;
            })
            .error(function(data) {
                console.log("ERROR: " + data);
            });




    }
 $scope.init();
});